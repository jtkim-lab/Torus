#!/usr/bin/python

import time

print "This is the first line"

time.sleep(1)

print "This is the second line"
