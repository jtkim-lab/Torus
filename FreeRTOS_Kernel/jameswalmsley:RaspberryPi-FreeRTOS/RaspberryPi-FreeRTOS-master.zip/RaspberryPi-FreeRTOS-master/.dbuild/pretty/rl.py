#!/usr/bin/python

import prettyformat
import sys

for line in prettyformat.readline(sys.stdin):
    print line
